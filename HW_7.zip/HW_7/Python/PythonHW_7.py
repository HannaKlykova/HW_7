import json

# Читання файлу spaces.json
with open('spaces.json', 'r', encoding='utf-8') as file:
    spaces = json.load(file)

# Перебір усіх spaces
for space in spaces:
    # Перевірка, чи є lists
    if 'lists' in space and isinstance(space['lists'], list):
        # Перебір lists
        for lst in space['lists']:
            # Перевірка, чи ім'я починається на 'test'
            if lst['name'].startswith('test'):
                # Виведення space.name, space.id та list.id
                print(f"{space['name']}\n{space['id']}\n{lst['id']}\n")