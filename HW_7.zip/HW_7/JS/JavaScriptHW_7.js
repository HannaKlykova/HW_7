const fs = require('fs');

// Читання файлу spaces.json
fs.readFile('spaces.json', 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading file:', err);
    return;
  }

  try {
    const spaces = JSON.parse(data);

    // Перебір усіх spaces
    spaces.forEach(space => {
      // Перевірка, чи є lists
      if (space.lists && Array.isArray(space.lists)) {
        // Перебір lists
        space.lists.forEach(list => {
          // Перевірка, чи ім'я починається на 'test'
          if (list.name.startsWith('test')) {
            // Виведення у потрібному форматі
            console.log(`${space.name}\n${space.id}\n`);
          }
        });
      }
    });
  } catch (parseError) {
    console.error('Error parsing JSON:', parseError);
  }
});