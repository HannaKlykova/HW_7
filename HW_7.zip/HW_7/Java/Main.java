import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        ObjectMapper objectMapper = new ObjectMapper();

        try {
            // Читання файлу spaces.json
            List<Map<String, Object>> spaces = objectMapper.readValue(new File("spaces.json"), new TypeReference<List<Map<String, Object>>>() {});

            // Перебір усіх spaces
            for (Map<String, Object> space : spaces) {
                // Отримуємо список lists
                List<Map<String, String>> lists = (List<Map<String, String>>) space.get("lists");
                
                if (lists != null) {
                    // Перебір lists
                    for (Map<String, String> list : lists) {
                        // Перевірка, чи ім'я починається на 'test'
                        if (list.get("name") != null && list.get("name").startsWith("test")) {
                            // Виведення space.name, space.id та list.id
                            System.out.println(space.get("name"));
                            System.out.println(space.get("id"));
                            System.out.println(list.get("id"));
                            System.out.println();
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}